import java.sql.*;

public class Assignment2 {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		Connection conn=null;
		try {
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
			System.out.println("Connection Established");
			conn.close();
		}
		
		catch(Exception e) {
			System.out.println("Connection not estalished");
		}
		
	}

}
