import java.sql.*;

public class Assignment1 {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		Connection conn=null;
		Statement stmt=null;
		ResultSet rs;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
			System.out.println("Connection Established");
		}
		catch(Exception e) {
			System.out.println("Connection not estalished");
			if(conn != null)
				conn.close();
		}
		
		String sql = "SELECT empno as index, ename as name FROM emp";
		stmt=conn.createStatement();
		rs=stmt.executeQuery(sql);
		
		while(rs.next()) {
			System.out.println("index: "+rs.getInt(1)+", name: "+rs.getString(2));
		}
		
		if(stmt != null)
			stmt.close();
		if(conn != null)
			conn.close();
		
	}

}
