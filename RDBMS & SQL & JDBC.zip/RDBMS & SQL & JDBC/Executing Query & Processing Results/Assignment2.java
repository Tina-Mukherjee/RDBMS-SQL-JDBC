import java.sql.*;

public class Assignment2 {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		Connection conn=null;
		Statement stmt=null;
		ResultSet rs;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:orcl","hr","hr");
			System.out.println("Connection Established");
		}
		catch(Exception e) {
			System.out.println("Connection not estalished");
			if(conn != null)
				conn.close();
		}
		
		String sql = "SELECT * FROM emp WHERE sal>1000 AND sal<2000";
		stmt=conn.createStatement();
		rs=stmt.executeQuery(sql);
		
		while(rs.next()) {
			System.out.println("empno: "+rs.getInt(1)+", ename: "+rs.getString(2)+", sal: "+rs.getInt(3)+", comm: "+rs.getInt(4));
		}
		
		if(stmt != null)
			stmt.close();
		if(conn != null)
			conn.close();
		
	}

}

