--Assignment:1
desc departments;
select * from departments;
--Assignment:2
desc employees;
select employee_id, last_name, job_id, hire_date as "STARTDATE" from employees;
--Assignment:3
select DISTINCT job_id from employees;
--Assignment:4
select employee_id "Emp #", last_name "Employee", job_id "Job", hire_date "Hire Date" from employees;
--Assignment:5
select last_name||', '||job_id as "Employee and Title" from employees;