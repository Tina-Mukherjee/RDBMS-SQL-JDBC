--Assignment:1
create table dept(
    dept_id number(7) PRIMARY KEY, 
    name varchar2(20) 
);
describe dept;
--Assignment:2
insert into dept
    select department_id,department_name from departments;
select * from dept;

--Following statements will give errors as it violates primary key rules and attribute type mismatch
insert into dept values(10,'Accounts');
insert into dept values(null,'TT');
update dept set dept_id=20 where name='TT';
insert into dept values(A1,'Accounts');
update dept set dept_id=30 where dept_id=A1;
