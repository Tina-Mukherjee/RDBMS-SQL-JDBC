--Assignment:3
create table emp(
    ID number(7),
    LAST_NAME varchar2(25) not null,
    FIRST_NAME varchar2(25),
    DEPT_ID number(7),
    primary key(ID),
    foreign key(DEPT_ID) references dept(dept_id)
);
insert into emp values(101,'Sam','Sundar',10);
insert into emp values(101,'Ram','Krishna',20);   --Give error
insert into emp values(102,'Gopi',null,40);
insert into emp values(103,null,'ram',20);    --Give error
select * from emp;