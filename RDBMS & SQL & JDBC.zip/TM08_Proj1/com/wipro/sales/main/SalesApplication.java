package TM08_Proj1.com.wipro.sales.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import TM08_Proj1.com.wipro.sales.bean.Product;
import TM08_Proj1.com.wipro.sales.bean.Sales;
import TM08_Proj1.com.wipro.sales.service.Administrator;

public class SalesApplication {
	public static void main(String args[]) throws ParseException {
		Scanner sc = new Scanner(System.in);
		Administrator admin = new Administrator();
		int choice = 0;
		
		do {
			System.out.println("1. Insert Stock\n2. Delete Stock\n3. Insert Sales\n4. View Sales Report\nEnter your Choice: ");
			choice = sc.nextInt();
			sc.nextLine();
			
			switch(choice) {
			case 1: 
				Product stock = new Product();
				System.out.print("Enter Product ID: ");
				stock.setProductID(sc.nextLine());
				System.out.print("Enter Product Name: ");
				stock.setProductName(sc.nextLine());
				System.out.print("Enter Quantity On Hand: ");
				stock.setQuantityOnHand(sc.nextInt());
				sc.nextLine();
				System.out.print("Enter Product Unit Price: ");
				stock.setProductUnitPrice(sc.nextDouble());
				System.out.print("Enter Product Reorder Level: ");
				stock.setReorderLevel(sc.nextInt());
				sc.nextLine();
				admin.insertStock(stock);
				break;
				
			case 2:
				System.out.print("Enter Product ID to be deleted: ");
				String removeId = sc.nextLine();
				removeId = admin.deleteStock(removeId);
				if(removeId != null)
					System.out.println(removeId + " removed successfully");
				break;
				
			case 3:
				Sales sales = new Sales();
				System.out.print("Enter Sales ID: ");
				sales.setSalesID(sc.nextLine());
				System.out.print("Enter date(dd-mm-yyyy): ");
				String sDate = sc.nextLine();
				Date date = new SimpleDateFormat("dd-mm-yyyy").parse(sDate);
				sales.setSalesDate(date);
				System.out.print("Enter Product ID: ");
				sales.setProductID(sc.nextLine());
				System.out.print("Enter Quantity Sold: ");
				sales.setQuantitySold(sc.nextInt());
				sc.nextLine();
				System.out.print("Enter Sales Price Per Unit: ");
				sales.setSalesPricePerUnit(sc.nextDouble());
				admin.insertSales(sales);
				break;
				
			case 4:
				admin.getSalesReport();
				break;
				
			case 5:
				System.out.println("Exiting...");
				choice = 0;
				break;
			}
		}while(choice >= 1 && choice <=4);
		sc.close();
	}
}
